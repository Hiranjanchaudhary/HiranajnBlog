
 <nav class="navbar fixed-top navbar-expand-lg navbar-dark  fixed-top bg-color-main" style="background-color:#1d2330">

      <div class="container">
        
      <h2 class="brand"><a href="index.php">Hiranjan<span style="color: #ff591cbb">B</span>log </a></h2>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        
          <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse" id="navbarResponsive">
          
          <ul class="navbar-nav ml-auto">
          </li>
                 <li class="nav-item">
              <a class="nav-link" href="index.php"> <i class="fa fa-home"></i> Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="category.php?catid=2"><i class="fa fa-bullhorn"></i> Politics</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="category.php?catid=3"><i class="fa fa-sport"></i> Sports</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="category.php?catid=7"><i class="fa fa-money"></i> business</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="category.php?catid=5"> <i class="fa fa-entertain"></i> Entertainment</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="category.php?catid=8"><i class="fa fa-bitcoin"></i> 	Cryptocurrency</a>
           </li>
             <li class="nav-item  w-f-u">
              <a class="nav-link" href="Write-for-us.php" > <i class="fa fa-book"></i> Write for Us</a>
            </li>
  
  
          </ul>
        </div>
      </div>
    </nav>